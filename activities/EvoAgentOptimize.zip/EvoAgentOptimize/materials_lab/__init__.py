from .model import MaterialsLabModel

__all__ = ['MaterialsLabModel']
